package com;

import java.util.Locale;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JSONObject1 extends JSONObject {

	public JSONObject1() {
		// TODO Auto-generated constructor stub
	}

	public JSONObject1(JSONTokener arg0) throws JSONException {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public JSONObject1(Map<?, ?> arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public JSONObject1(Object bean) {
		super(bean);
		// TODO Auto-generated constructor stub
	}

	public JSONObject1(String source) throws JSONException {
		super(source);
		// TODO Auto-generated constructor stub
	}

	public JSONObject1(int initialCapacity) {
		super(initialCapacity);
		// TODO Auto-generated constructor stub
	}

	public JSONObject1(JSONObject arg0, String[] arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public JSONObject1(Object arg0, String[] arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public JSONObject1(String arg0, Locale arg1) throws JSONException {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
