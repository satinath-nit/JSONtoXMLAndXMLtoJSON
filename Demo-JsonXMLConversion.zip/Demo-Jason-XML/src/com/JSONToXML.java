package com;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.LinkedHashMap;

import org.json.JSONObject;
import org.json.XML;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.google.gson.JsonParser;

public class JSONToXML {

	public static void main(String[] args) throws IOException, ParseException, IllegalArgumentException, IllegalAccessException, SecurityException, NoSuchFieldException {
		//JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();
        FileReader reader = new FileReader("C:/Users/smondabj/Walgreens/EclipseWorkspace/Demo-Jason-XML/src/com/test.json") ;       
		
		
		String jsonObject = jsonParser.parse(reader).toString();
		//LinkedHashMap details = new Gson().fromJson(jsonObject, LinkedHashMap.class);
		
		//{"firstName": "Rack", "lastName": "Jackon","gender": "man","age": 24,"address": { "streetAddress": "126","city": "San Jone","state": "CA", "postalCode": "394221"},  "phoneNumbers": [{ "type": "home", "number": "7383627627" }]}
		LinkedHashMap details = new Gson().fromJson("{\"firstName\": \"Rack\", \"lastName\": \"Jackon\",\"gender\": \"man\",\"age\": 24,\"address\": { \"streetAddress\": \"126\",\"city\": \"San Jone\",\"state\": \"CA\", \"postalCode\": \"394221\"},  \"phoneNumbers\": [{ \"type\": \"home\", \"number\": \"7383627627\" }]}", LinkedHashMap.class);
		JSONObject obj = new JSONObject(details);
		
		
		//converting json to xml
		String xml_data = XML.toString(obj);
		
		System.out.println(xml_data);

	}

}
