package com;

import org.json.JSONObject;
import org.json.XML;

public class XMLToJSON {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String xml_data = "<firstName>Rack</firstName><lastName>Jackon</lastName><gender>man</gender><age>24.0</age><address><streetAddress>126</streetAddress><city>San Jone</city><state>CA</state><postalCode>394221</postalCode></address><phoneNumbers><type>home</type><number>7383627627</number></phoneNumbers>";
		 
		//converting xml to json
		JSONObject obj = XML.toJSONObject(xml_data);
		
		System.out.println(obj.toString());

	}

}
